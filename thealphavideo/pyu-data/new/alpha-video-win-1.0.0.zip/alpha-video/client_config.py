class ClientConfig(object):
    PUBLIC_KEY = 'gRExNHZca67GgQHHZYhKoZdUShKOh0SqDsfcSHuTVSw'
    APP_NAME = 'alpha-video'
    COMPANY_NAME = 'alpha-video'
    HTTP_TIMEOUT = 30
    MAX_DOWNLOAD_RETRIES = 3
    UPDATE_URLS = ['https://updates.andrewstech.me']
